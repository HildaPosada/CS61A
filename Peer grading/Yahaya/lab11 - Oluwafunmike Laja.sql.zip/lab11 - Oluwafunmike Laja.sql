CREATE table newest AS
  SELECT title, year
  FROM titles
  ORDER BY year DESC
  LIMIT 10;

CREATE table dog_movies AS 
  SELECT title, character FROM titles, principals
    WHERE titles.tconst = principals.tconst AND character LIKE '%dog%';


CREATE table leads AS 
  SELECT name, COUNT(*) AS lead_roles
  FROM names, principals
  WHERE names.nconst = principals.nconst
    AND ordering = 1
  GROUP BY names.nconst
  HAVING lead_roles > 10;


CREATE table long_movies AS 
  SELECT (year / 10 * 10) || 's' AS decade, COUNT(*) AS count
  FROM titles
  WHERE runtime > 180
  GROUP BY decade;

