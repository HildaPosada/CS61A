CREATE TABLE newest AS
SELECT title, year
FROM titles
ORDER BY year DESC
LIMIT 10;

CREATE TABLE dog_movies AS
SELECT titles.title, principals.character
FROM titles, principals
WHERE titles.tconst = principals.tconst
  AND principals.character LIKE '%dog%';

CREATE TABLE leads AS
SELECT names.name, COUNT(*) AS lead_roles
FROM names, principals
WHERE names.nconst = principals.nconst
  AND principals.ordering = 1
GROUP BY names.name
HAVING COUNT(*) > 10;


CREATE TABLE long_movies AS
SELECT
  ((year / 10) * 10) || 's' AS decade,
  COUNT(*) AS count
FROM titles
WHERE runtime > 180
GROUP BY decade
ORDER BY decade;

